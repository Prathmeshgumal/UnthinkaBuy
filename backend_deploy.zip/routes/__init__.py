"""
Routes package initialization
"""
